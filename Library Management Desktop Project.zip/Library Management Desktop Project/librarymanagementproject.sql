-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.41-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema librarymgmtst
--

CREATE DATABASE IF NOT EXISTS librarymgmtst;
USE librarymgmtst;

--
-- Definition of table `adminelogin`
--

DROP TABLE IF EXISTS `adminelogin`;
CREATE TABLE `adminelogin` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(45) default NULL,
  `password` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminelogin`
--

/*!40000 ALTER TABLE `adminelogin` DISABLE KEYS */;
INSERT INTO `adminelogin` (`id`,`username`,`password`) VALUES 
 (1,'redwan','123'),
 (2,'abc','123');
/*!40000 ALTER TABLE `adminelogin` ENABLE KEYS */;


--
-- Definition of table `book_table`
--

DROP TABLE IF EXISTS `book_table`;
CREATE TABLE `book_table` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `book_id` varchar(45) default NULL,
  `book_name` varchar(45) default NULL,
  `avail_book` int(10) unsigned default NULL,
  `book_loc` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_table`
--

/*!40000 ALTER TABLE `book_table` DISABLE KEYS */;
INSERT INTO `book_table` (`id`,`book_id`,`book_name`,`avail_book`,`book_loc`) VALUES 
 (1,'01','core java',8,'01A1209'),
 (2,'02','basic java',22,'01A1208'),
 (3,'03','uml',15,NULL),
 (4,'04','jsp',10,NULL),
 (5,'05','html',10,NULL),
 (6,'06','xml',7,NULL),
 (7,'07','php',18,NULL),
 (8,'08','bangla',13,NULL),
 (9,'09','english',13,NULL),
 (10,'12','math',50,NULL),
 (11,'10','s.science',12,NULL),
 (12,'121','csc',4,NULL),
 (13,'11','Histry',6,NULL),
 (14,'0001','gave',5,NULL),
 (15,'157','hjkumlhdh',11,NULL),
 (16,'11111','jhgjgSpringjhg',111,NULL),
 (17,'2211','economics',7,NULL);
/*!40000 ALTER TABLE `book_table` ENABLE KEYS */;


--
-- Definition of table `student_info`
--

DROP TABLE IF EXISTS `student_info`;
CREATE TABLE `student_info` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `roll` varchar(45) default NULL,
  `name` varchar(45) default NULL,
  `dept` varchar(45) default NULL,
  `rented_book` varchar(45) default 'Not Issued Yet',
  `rent_date` varchar(45) default 'N/A',
  `return_date` varchar(45) default 'N/A',
  `reg_date` varchar(45) default NULL,
  `phone` varchar(45) default NULL,
  `rented_book_id` varchar(45) default 'N/A',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

/*!40000 ALTER TABLE `student_info` DISABLE KEYS */;
INSERT INTO `student_info` (`id`,`roll`,`name`,`dept`,`rented_book`,`rent_date`,`return_date`,`reg_date`,`phone`,`rented_book_id`) VALUES 
 (1,'0000','AAA','DDD','BBB','0000-00-00','N/A','0000-00-00','0000000',NULL),
 (2,'123','CaPati','CSE','Not Issued Yet','2019-12-15','2019-12-30','2019-11-21','01900000000','03'),
 (3,'124','Redwan','TCLD','basic java','2019-11-21','2019-12-06','2019-11-21','01948241686','02'),
 (7,'111','MD. Redwan ullah','j2ee','Not Issued Yet','2019-12-07','2019-12-22','12/7/2019','01948241686','06'),
 (8,'222','Jobayer','j2ee','uml','2019-12-07','2019-12-22','11/7/2019','01948241668',''),
 (9,'333','foysal','j2ee','uml','2019-12-07','2019-12-22','1o/7/2019','01948251686',''),
 (10,'444','helal','j2ee','html','2019-12-07','2019-12-22','2019-12-07','01948245689',''),
 (11,'888','jamal','phhp','Not Issued Yet','N/A','N/A','2019-12-07','0194852487','N/A'),
 (12,'888','jamal','phhp','Not Issued Yet','N/A','N/A','2019-12-07','0194852487','N/A'),
 (13,'555','kamal','ddd','Not Issued Yet','2019-12-07','2019-12-22','2019-12-07','019845746','08'),
 (14,'','','','Not Issued Yet','N/A','N/A','2019-12-07','','N/A'),
 (15,'9856','sdf','adf','Not Issued Yet','N/A','N/A','2019-12-07','222','N/A'),
 (16,'999','xyz','ddd','s.science','2019-12-08','2019-12-23','2019-12-08','01685472','10'),
 (17,'666','mojid','j2ee','Not Issued Yet','2019-12-08','2019-12-23','2019-12-08','01948241668','06'),
 (18,'777','noyon','php','Not Issued Yet','2019-12-08','2019-12-23','2019-12-08','019758462','11'),
 (19,'1122','raju','tcld','Not Issued Yet','2019-12-14','2019-12-29','2019-12-14','01245879','0001'),
 (20,'22211','salam','java','Not Issued Yet','2019-12-15','2019-12-30','2019-12-15','01948241665','2211');
/*!40000 ALTER TABLE `student_info` ENABLE KEYS */;


--
-- Definition of table `userlogin`
--

DROP TABLE IF EXISTS `userlogin`;
CREATE TABLE `userlogin` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `UName` varchar(45) default NULL,
  `UID` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlogin`
--

/*!40000 ALTER TABLE `userlogin` DISABLE KEYS */;
INSERT INTO `userlogin` (`id`,`UName`,`UID`) VALUES 
 (1,'asd','123');
/*!40000 ALTER TABLE `userlogin` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
